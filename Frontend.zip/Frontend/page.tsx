"use client";

import React from "react";
import KPIDashboard from "../app/components/KPIDashboard";
import Sidebar from ".//components/Sidebar";
const DashboardPage: React.FC = () => {
  return (
    <div className="flex">
      {/* Sidebar only here */}
      <Sidebar />
      <main className="ml-64 flex-1 bg-gray-50 min-h-screen p-6">
        <KPIDashboard />
      </main>
    </div>
  );
};

export default DashboardPage;
