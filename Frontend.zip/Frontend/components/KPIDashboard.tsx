"use client";
import React, { useState, useEffect } from "react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid, LabelList,
} from "recharts";
import { FaUserFriends, FaCarSide, FaBus, FaPercentage } from "react-icons/fa";
import HeaderBanner from "./HeaderBanner";
import KPIBox from "./KPIBox";
import YearMonthPopupFilter from "./YearMonthPopupFilter";

const monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

const KPIDashboard: React.FC = () => {
  const today = new Date();
  const currentYear = today.getFullYear();
  const defaultHistMonth = today.getMonth() + 1;

  // Historical Filters
  const [showHistFilters, setShowHistFilters] = useState(false);
  const [histShift, setHistShift] = useState("Morning");
  const [histYear, setHistYear] = useState(currentYear);
  const [histMonth, setHistMonth] = useState(defaultHistMonth);
  const [histEventType, setHistEventType] = useState("Login");

  // Forecast Filters
  const [showFcFilters, setShowFcFilters] = useState(false);
  const [fcShift, setFcShift] = useState("Morning");
  const [fcYear, setFcYear] = useState(currentYear);
  const [fcMonth, setFcMonth] = useState(defaultHistMonth);
  const [fcEventType, setFcEventType] = useState("Login");

  // Data States
  const [histData, setHistData] = useState<any[]>([]);
  const [histKPIs, setHistKPIs] = useState<any>({});
  const [forecastData, setForecastData] = useState<any[]>([]);
  const [forecastKPIs, setForecastKPIs] = useState<any>({});
  const [forecastAccuracy, setForecastAccuracy] = useState<number>(0);

  // Fetch Historical
  useEffect(() => {
    async function fetchHistorical() {
      const res = await fetch(`/api/historical?shift=${histShift}&year=${histYear}&month=${histMonth}&event=${histEventType}`);
      const data = await res.json();
      setHistData(data.chartData);
      setHistKPIs(data.kpis);
    }
    fetchHistorical();
  }, [histShift, histYear, histMonth, histEventType]);

  // Fetch Forecast
  useEffect(() => {
    async function fetchForecast() {
      const res = await fetch(`/api/forecast?shift=${fcShift}&mode=Month&date=${fcYear}-${fcMonth}-01&event=${fcEventType}`);
      const data = await res.json();
      setForecastData(data.chartData);
      setForecastKPIs(data.kpis);
      setForecastAccuracy(data.kpis.accuracy || 0);
    }
    fetchForecast();
  }, [fcShift, fcYear, fcMonth, fcEventType]);

  return (
    <div className="bg-gray-50 min-h-screen">
      <HeaderBanner />
      <div className="max-w-7xl mx-auto px-[50px] py-8 space-y-10">
        
        {/* -------------------- HISTORICAL -------------------- */}
        <div className="border rounded-md shadow-sm bg-white">
          <div
            className="flex justify-between items-center px-4 py-2 cursor-pointer"
            onClick={() => setShowHistFilters((f) => !f)}
          >
            <span className="font-medium text-gray-700">Historical Filters</span>
            <svg className={`w-4 h-4 text-gray-500 transform transition-transform ${showHistFilters ? "rotate-180" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </div>
          {showHistFilters && (
            <div className="px-4 py-4 border-t bg-gradient-to-r from-blue-50 to-cyan-50 shadow-md rounded-b-lg flex flex-wrap gap-6">
              {/* Shift */}
              <div className="flex flex-col text-sm w-full md:w-[30%]">
                <label className="mb-1 font-medium text-gray-600">Shift</label>
                <select className="border rounded p-2 bg-white" value={histShift} onChange={(e) => setHistShift(e.target.value)}>
                  {["Morning","General","Midday","Night"].map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </div>
              {/* Month-Year */}
              <div className="flex flex-col items-center text-sm w-full md:w-[30%]">
                <label className="mb-1 font-medium text-gray-600">Month & Year</label>
                <YearMonthPopupFilter
                  year={histYear}
                  month={histMonth}
                  onChange={(y, m) => { setHistYear(y); setHistMonth(m); }}
                  range={{ past: 5, future: 2 }}
                />
              </div>
              {/* Event Type */}
              <div className="flex flex-col text-sm w-full md:w-[30%]">
                <label className="mb-1 font-medium text-gray-600">Event Type</label>
                <select className="border rounded p-2 bg-white" value={histEventType} onChange={(e) => setHistEventType(e.target.value)}>
                  {["Login","Logout"].map((et) => (
                    <option key={et}>{et}</option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>

        <div className="rounded-lg p-6 bg-gradient-to-r from-blue-50 to-cyan-50 shadow space-y-6">
          <h2 className="text-xl font-semibold text-blue-600 text-center">
            Historical ({monthNames[histMonth - 1]} {histYear})
          </h2>
          <div className="flex flex-wrap justify-center gap-4">
            <KPIBox icon={<FaUserFriends />} title="Employees Booked" value={histKPIs.employees || 0} color="blue" />
            <KPIBox icon={<FaCarSide />} title="3-Seater Rides" value={histKPIs.rides3 || 0} color="blue" />
            <KPIBox icon={<FaCarSide />} title="5-Seater Rides" value={histKPIs.rides5 || 0} color="blue" />
            <KPIBox icon={<FaBus />} title="8-Seater Rides" value={histKPIs.rides8 || 0} color="blue" />
            <KPIBox icon={<FaPercentage />} title="No-Show Rate %" value={histKPIs.noShowRate || 0} color="blue" />
          </div>

          <div style={{ width: "100%", height: 300 }}>
            <ResponsiveContainer>
              <BarChart data={histData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 10 }} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="noShows" fill="#60A5FA">
                  <LabelList dataKey="noShows" position="top" style={{ fontSize: 10 }} />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* -------------------- FORECAST -------------------- */}
        <div className="border rounded-md shadow-sm bg-white">
          <div
            className="flex justify-between items-center px-4 py-2 cursor-pointer"
            onClick={() => setShowFcFilters((f) => !f)}
          >
            <span className="font-medium text-gray-700">Forecast Filters</span>
            <svg className={`w-4 h-4 text-gray-500 transform transition-transform ${showFcFilters ? "rotate-180" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </div>
          {showFcFilters && (
            <div className="px-4 py-4 border-t bg-gradient-to-r from-red-50 to-pink-50 shadow-md rounded-b-lg flex flex-wrap gap-6">
              {/* Shift */}
              <div className="flex flex-col text-sm w-full md:w-[30%]">
                <label className="mb-1 font-medium text-gray-600">Shift</label>
                <select className="border rounded p-2 bg-white" value={fcShift} onChange={(e) => setFcShift(e.target.value)}>
                  {["Morning","General","Midday","Night"].map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </div>
              {/* Month-Year */}
              <div className="flex flex-col items-center text-sm w-full md:w-[30%]">
                <label className="mb-1 font-medium text-gray-600">Month & Year</label>
                <YearMonthPopupFilter
                  year={fcYear}
                  month={fcMonth}
                  onChange={(y, m) => { setFcYear(y); setFcMonth(m); }}
                  range={{ past: 5, future: 2 }}
                />
              </div>
              {/* Event Type */}
              <div className="flex flex-col text-sm w-full md:w-[30%]">
                <label className="mb-1 font-medium text-gray-600">Event Type</label>
                <select className="border rounded p-2 bg-white" value={fcEventType} onChange={(e) => setFcEventType(e.target.value)}>
                  {["Login","Logout"].map((et) => (
                    <option key={et}>{et}</option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>

        <div className="rounded-lg p-6 bg-gradient-to-r from-red-50 to-pink-50 shadow space-y-6">
          <h2 className="text-xl font-semibold text-red-600 text-center">
            Forecast ({monthNames[fcMonth - 1]} {fcYear})
          </h2>
          <div className="flex flex-wrap justify-center gap-4">
            <KPIBox icon={<FaUserFriends />} title="Employees Forecast" value={forecastKPIs.employees || 0} color="red" />
            <KPIBox icon={<FaCarSide />} title="3-Seater Forecast" value={forecastKPIs.rides3 || 0} color="red" />
            <KPIBox icon={<FaCarSide />} title="5-Seater Forecast" value={forecastKPIs.rides5 || 0} color="red" />
            <KPIBox icon={<FaBus />} title="8-Seater Forecast" value={forecastKPIs.rides8 || 0} color="red" />
            <KPIBox icon={<FaPercentage />} title="No-Show Forecast %" value={forecastKPIs.noShowRate || 0} color="red" />
            <KPIBox icon={<FaPercentage />} title="Accuracy %" value={forecastAccuracy} color="green" />
          </div>

          <div style={{ width: "100%", height: 300 }}>
            <ResponsiveContainer>
              <BarChart data={forecastData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 10 }} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="forecast" fill="#EF4444">
                  <LabelList dataKey="forecast" position="top" style={{ fontSize: 10 }} />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default KPIDashboard;
