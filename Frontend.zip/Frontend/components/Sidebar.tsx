"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { FaChartLine, FaHome } from "react-icons/fa";

const Sidebar: React.FC = () => {
  const pathname = usePathname();

  const menuItems = [
    { name: "Dashboard", href: "/", icon: <FaHome /> },
    { name: "Data Forecast", href: "/data-forecast", icon: <FaChartLine /> },
  ];

  return (
    <aside className="h-screen w-64 bg-white shadow-lg fixed left-0 top-0 flex flex-col">
      <div className="px-6 py-4 text-xl font-bold text-blue-700 border-b">
        Cab Forecast
      </div>
      <nav className="flex-1 px-4 py-6 space-y-2">
        {menuItems.map((item) => (
          <Link
            key={item.name}
            href={item.href}
            className={`flex items-center gap-3 p-3 rounded-lg text-gray-700 hover:bg-blue-100 hover:text-blue-700 transition 
              ${pathname === item.href ? "bg-blue-100 text-blue-700 font-medium" : ""}`}
          >
            {item.icon}
            {item.name}
          </Link>
        ))}
      </nav>
    </aside>
  );
};

export default Sidebar;
