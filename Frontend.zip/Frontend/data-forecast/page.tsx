"use client";
import Link from "next/link";
import { FaHome } from "react-icons/fa";

export default function DataForecastPage() {
  return (
    <div className="p-10 bg-white rounded shadow-md min-h-screen">
      {/* Header with Home Button */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-blue-600">Data Forecast</h1>
        <Link
          href="/"
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
        >
          <FaHome /> Home
        </Link>
      </div>

      <p className="text-gray-700">This is a placeholder page for Data Forecast.</p>
    </div>
  );
}
